public class main {
    public static void main(String[] args) {
        
        Lista Vitor = new Lista(4);

        Vitor.AdicionarElemento(34);
        Vitor.AdicionarElemento(22);

        System.out.println(Vitor.AdicionarElemento(65));

        System.out.println(Vitor.OrdenarLista());
        
    }
}
