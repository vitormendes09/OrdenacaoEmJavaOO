class Lista{

    private int vetordeDados[];
    private int total;
    private int primeiro;
    private int ultimo;
    private int tamanhoMaximo;


    public Lista(int novoTamanhoMaximo){

        this.vetordeDados = new int [novoTamanhoMaximo];
        this.tamanhoMaximo = novoTamanhoMaximo;
        this.total = 0;
        this.ultimo = 0;
        this.primeiro = 0;

    }

    public boolean AdicionarElemento(int novoElemento){

        if(tamanhoMaximo > total){
            vetordeDados[ultimo] = novoElemento;
            ultimo = (ultimo + 1) % vetordeDados.length;
            total ++;
            return true;
        }
        return false;
    }


    public boolean ExcluirElemento(){
        
        if(tamanhoMaximo < total){
            int controle = vetordeDados[primeiro];
            primeiro = (primeiro + 1) % vetordeDados.length;
            total --;
            return true;

        }
        
        return false;
    }

    // Foi escolhido o método bolha
    public boolean OrdenarLista(){

        int tamanhoMaximo = total;
        boolean existiuTroca;

        do{
            existiuTroca = false;
            for(int posicaoVetor = 0; posicaoVetor < tamanhoMaximo -1; posicaoVetor++){
                if(vetordeDados[posicaoVetor] > vetordeDados[posicaoVetor + 1]){
                    trocarValores(vetordeDados, posicaoVetor, posicaoVetor +1);
                    existiuTroca = true;
                }
            }

        }while(existiuTroca);
       
        return true;
    }

    private static void trocarValores(int[] vetordeDados, int primeiraPosicao, int segundaPosicao){

        int armazenamentoAuxiliar;

		armazenamentoAuxiliar = vetordeDados[primeiraPosicao];

		vetordeDados[primeiraPosicao] = vetordeDados[segundaPosicao];
		vetordeDados[segundaPosicao] = armazenamentoAuxiliar;
    }

}